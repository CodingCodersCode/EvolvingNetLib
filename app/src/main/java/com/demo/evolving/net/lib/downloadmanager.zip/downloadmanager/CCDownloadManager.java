package com.demo.evolving.net.lib.downloadmanager;


import com.codingcoderscode.evolving.net.CCRxNetManager;
import com.codingcoderscode.evolving.net.cache.mode.CCCacheMode;
import com.codingcoderscode.evolving.net.request.CCDownloadRequest;
import com.codingcoderscode.evolving.net.request.callback.CCNetCallback;
import com.codingcoderscode.evolving.net.request.canceler.CCCanceler;
import com.codingcoderscode.evolving.net.util.NetLogUtil;

import java.util.List;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by ghc on 2017/11/7.
 * <p>
 * 下载管理类，封装多线程下载，任务自动管理和调度等功能
 */

public class CCDownloadManager extends CCNetCallback {

    private final String LOG_TAG = getClass().getCanonicalName();

    private PriorityBlockingQueue<CCDownloadTask> taskToDownload;
    private PriorityBlockingQueue<CCDownloadTask> taskDownloading;
    private PriorityBlockingQueue<CCDownloadTask> taskCompleted;
    //同时存在的最大任务数量
    private int maxTaskCount;
    //已经存在的任务数量
    private AtomicInteger existTaskCount;

    private CCNetCallback ccNetCallback;

    private final int DEFAULT_RETRY_COUNT = 3;

    public CCDownloadManager(PriorityBlockingQueue<CCDownloadTask> taskToDownload, int maxTaskCount) {
        this.taskToDownload = new PriorityBlockingQueue<CCDownloadTask>();
        this.taskToDownload.addAll(taskToDownload);
        this.taskDownloading = new PriorityBlockingQueue<CCDownloadTask>();
        this.taskCompleted = new PriorityBlockingQueue<CCDownloadTask>();
        this.maxTaskCount = maxTaskCount;
        existTaskCount = new AtomicInteger(0);
    }

    public static class Builder {

        private PriorityBlockingQueue<CCDownloadTask> taskBlockingQueue;

        private int maxTaskCount;

        public Builder() {
            this.taskBlockingQueue = new PriorityBlockingQueue<CCDownloadTask>();
            this.maxTaskCount = 0;
        }

        public Builder addTask(CCDownloadTask task) {
            this.taskBlockingQueue.add(task);
            return this;
        }

        public Builder addTasks(List<CCDownloadTask> taskList) {

            if (taskList != null && taskList.size() > 0) {
                this.taskBlockingQueue.addAll(taskList);
            }
            return this;
        }

        public Builder setMaxTaskCount(int maxTaskCount) {
            this.maxTaskCount = maxTaskCount;
            return this;
        }

        public CCDownloadManager build() {
            return new CCDownloadManager(this.taskBlockingQueue, this.maxTaskCount);
        }
    }

    public void execute() {
        try {

            if (taskToDownload == null || taskToDownload.isEmpty()) {
                NetLogUtil.printLog("e", LOG_TAG, "可下载目标任务数量为0，不开启下载");
                return;
            }

            if (maxTaskCount <= 0) {
                maxTaskCount = 1;
                NetLogUtil.printLog("e", LOG_TAG, "下载任务数量小于0，默认初始化为1");
            }

            tryToStartNewDownloadTask();

        } catch (Exception e) {

        }
    }

    public void start(String taskKey){

    }

    public void start(CCDownloadTask task){

    }

    public void pause(String taskKey){

    }

    public void pause(CCDownloadTask task){

    }

    public void resume(String taskKey){
        start(taskKey);
    }

    public void resume(CCDownloadTask task){
        start(task);
    }

    public CCDownloadTask getATaskToDownload() {
        return this.taskToDownload.poll();
    }

    public synchronized void tryToStartNewDownloadTask() {

        try {

            while (existTaskCount.intValue() < maxTaskCount) {

                CCDownloadTask task2Download = getATaskToDownload();

                if (task2Download != null) {
                    existTaskCount.getAndIncrement();
                    onCreateAndStartTask(task2Download);
                }
            }

        } catch (Exception e) {

        }

    }

    private void onCreateAndStartTask(CCDownloadTask downloadTask) {
        try {

            CCDownloadRequest downloadRequest = CCRxNetManager.<Void>download(downloadTask.getSourceUrl())
                    //.setHeaderMap(new HashMap<String, String>())
                    //.setPathMap(new HashMap<String, String>())
                    .setFileSavePath(downloadTask.getSavePath())
                    .setFileSaveName(downloadTask.getSaveName())
                    .setRetryCount(DEFAULT_RETRY_COUNT)
                    .setCacheQueryMode(CCCacheMode.QueryMode.MODE_ONLY_NET)
                    .setCacheSaveMode(CCCacheMode.SaveMode.MODE_NO_CACHE)
                    .setReqTag(downloadTask.getTaskKey())
                    .setSupportRage(true)
                    .setCCNetCallback(this)
                    .setNetLifecycleComposer(downloadTask.getNetLifecycleComposer())
                    .setResponseBeanType(Void.class);

            downloadRequest.executeAsync();


        } catch (Exception e) {

        }
    }


    @Override
    public <T> void onStartRequest(Object reqTag, CCCanceler canceler) {
        if (ccNetCallback != null) {
            ccNetCallback.onStartRequest(reqTag, canceler);
        }
    }

    @Override
    public <T> void onSuccess(Object reqTag, T response) {
        if (ccNetCallback != null) {
            ccNetCallback.onSuccess(reqTag, response);
        }
    }

    @Override
    public <T> void onError(Object reqTag, Throwable t) {
        if (ccNetCallback != null) {
            ccNetCallback.onError(reqTag, t);
        }
    }

    @Override
    public <T> void onComplete(Object reqTag) {
        if (ccNetCallback != null) {
            ccNetCallback.onComplete(reqTag);
        }
        existTaskCount.getAndDecrement();
        tryToStartNewDownloadTask();
    }

    @Override
    public <T> void onProgress(Object reqTag, int progress, long netSpeed, long completedSize, long fileSize) {
        if (ccNetCallback != null) {
            ccNetCallback.onProgress(reqTag, progress, netSpeed, completedSize, fileSize);
        }
    }

    @Override
    public <T> void onProgressSave(Object reqTag, int progress, long netSpeed, long completedSize, long fileSize) {
        if (ccNetCallback != null) {
            ccNetCallback.onProgressSave(reqTag, progress, netSpeed, completedSize, fileSize);
        }
    }


    public CCNetCallback getCcNetCallback() {
        return ccNetCallback;
    }

    public void setCcNetCallback(CCNetCallback ccNetCallback) {
        this.ccNetCallback = ccNetCallback;
    }
}
