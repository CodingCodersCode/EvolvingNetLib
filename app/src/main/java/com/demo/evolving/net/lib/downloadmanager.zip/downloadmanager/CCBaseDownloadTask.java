package com.demo.evolving.net.lib.downloadmanager;

import com.codingcoderscode.evolving.net.response.CCBaseResponse;
import com.trello.rxlifecycle2.android.ActivityEvent;
import com.trello.rxlifecycle2.android.FragmentEvent;
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity;
import com.trello.rxlifecycle2.components.support.RxFragment;

import io.reactivex.FlowableTransformer;

/**
 * Created by ghc on 2017/11/7.
 *
 *
 */

public abstract class CCBaseDownloadTask {
    private FlowableTransformer<CCBaseResponse<Void>, CCBaseResponse<Void>> netLifecycleComposer;

    public CCBaseDownloadTask() {
        this.netLifecycleComposer = null;
    }

    public CCBaseDownloadTask(RxAppCompatActivity activity) {
        this.netLifecycleComposer = activity.bindUntilEvent(ActivityEvent.DESTROY);
    }

    public CCBaseDownloadTask(RxFragment fragment) {
        this.netLifecycleComposer = fragment.bindUntilEvent(FragmentEvent.DESTROY);
    }

    public FlowableTransformer<CCBaseResponse<Void>, CCBaseResponse<Void>> getNetLifecycleComposer() {
        return netLifecycleComposer;
    }

    public void setNetLifecycleComposer(FlowableTransformer<CCBaseResponse<Void>, CCBaseResponse<Void>> netLifecycleComposer) {
        this.netLifecycleComposer = netLifecycleComposer;
    }
}
