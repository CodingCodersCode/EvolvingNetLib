package com.demo.evolving.net.lib.downloadmanager;

/**
 * Created by ghc on 2017/11/7.
 */

public class CCDownloadStatus {
    public static final int DOWNLOADING = 0;
    public static final int WAIT = 1;
    public static final int PAUSED = 2;
    public static final int COMPLETED = 3;
}
