package com.demo.evolving.net.lib.downloadmanager;

import android.support.annotation.NonNull;

import com.trello.rxlifecycle2.components.support.RxAppCompatActivity;
import com.trello.rxlifecycle2.components.support.RxFragment;

/**
 * Created by ghc on 2017/11/7.
 */

public class CCDownloadTask extends CCBaseDownloadTask implements Comparable<CCDownloadTask> {

    private String taskKey;
    private String sourceUrl;
    private String savePath;
    private String saveName;
    private long fileSize;
    private long completedSize;
    private int priority;
    private int downloadStatus;

    public CCDownloadTask(String taskKey, String sourceUrl, String savePath, String saveName, long fileSize, long completedSize, int priority) {
        super();
        this.taskKey = taskKey;
        this.sourceUrl = sourceUrl;
        this.savePath = savePath;
        this.saveName = saveName;
        this.fileSize = fileSize;
        this.completedSize = completedSize;
        this.priority = priority;
        this.downloadStatus = CCDownloadStatus.WAIT;
    }

    public CCDownloadTask(RxAppCompatActivity activity, String taskKey, String savePath, String saveName, String saveUrl, long fileSize, long completedSize, int priority) {
        super(activity);
        this.taskKey = taskKey;
        this.sourceUrl = sourceUrl;
        this.savePath = savePath;
        this.saveName = saveName;
        this.fileSize = fileSize;
        this.completedSize = completedSize;
        this.priority = priority;
        this.downloadStatus = CCDownloadStatus.WAIT;
    }

    public CCDownloadTask(RxFragment fragment, String taskKey, String sourceUrl, String savePath, String saveName, long fileSize, long completedSize, int priority) {
        super(fragment);
        this.taskKey = taskKey;
        this.sourceUrl = sourceUrl;
        this.savePath = savePath;
        this.saveName = saveName;
        this.fileSize = fileSize;
        this.completedSize = completedSize;
        this.priority = priority;
        this.downloadStatus = CCDownloadStatus.WAIT;
    }





    @Override
    public int compareTo(@NonNull CCDownloadTask o) {
        if (this == o) {
            return 0;
        } else {
            if (this.downloadStatus == CCDownloadStatus.WAIT) {

                switch (o.downloadStatus) {
                    case CCDownloadStatus.WAIT:
                        return this.priority - o.priority;
                    case CCDownloadStatus.PAUSED:
                        return -1;
                    case CCDownloadStatus.DOWNLOADING:
                        return 1;
                    case CCDownloadStatus.COMPLETED:
                        return -1;
                }

            } else if (this.downloadStatus == CCDownloadStatus.PAUSED) {

                switch (o.downloadStatus) {
                    case CCDownloadStatus.WAIT:
                        return 1;
                    case CCDownloadStatus.PAUSED:
                        return this.priority - o.priority;
                    case CCDownloadStatus.DOWNLOADING:
                        return 1;
                    case CCDownloadStatus.COMPLETED:
                        return -1;
                }

            } else if (this.downloadStatus == CCDownloadStatus.DOWNLOADING) {

                switch (o.downloadStatus) {
                    case CCDownloadStatus.WAIT:
                        return -1;
                    case CCDownloadStatus.PAUSED:
                        return -1;
                    case CCDownloadStatus.DOWNLOADING:
                        return this.priority - o.priority;
                    case CCDownloadStatus.COMPLETED:
                        return -1;
                }

            } else if (this.downloadStatus == CCDownloadStatus.COMPLETED) {

                switch (o.downloadStatus) {
                    case CCDownloadStatus.WAIT:
                        return 1;
                    case CCDownloadStatus.PAUSED:
                        return 1;
                    case CCDownloadStatus.DOWNLOADING:
                        return 1;
                    case CCDownloadStatus.COMPLETED:
                        return this.priority - o.priority;
                }
            }
            return this.priority - o.priority;
        }
    }

    public String getTaskKey() {
        return taskKey;
    }

    public void setTaskKey(String taskKey) {
        this.taskKey = taskKey;
    }

    public String getSourceUrl() {
        return sourceUrl;
    }

    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    public String getSavePath() {
        return savePath;
    }

    public void setSavePath(String savePath) {
        this.savePath = savePath;
    }

    public String getSaveName() {
        return saveName;
    }

    public void setSaveName(String saveName) {
        this.saveName = saveName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public long getCompletedSize() {
        return completedSize;
    }

    public void setCompletedSize(long completedSize) {
        this.completedSize = completedSize;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getDownloadStatus() {
        return downloadStatus;
    }

    public void setDownloadStatus(int downloadStatus) {
        this.downloadStatus = downloadStatus;
    }
}